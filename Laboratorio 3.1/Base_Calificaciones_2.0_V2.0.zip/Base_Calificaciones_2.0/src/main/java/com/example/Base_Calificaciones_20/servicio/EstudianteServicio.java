package com.example.Base_Calificaciones_20.servicio;

import com.example.Base_Calificaciones_20.modelo.EstudianteModelo;
import com.example.Base_Calificaciones_20.repositorio.EstudianteRepositorio;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class EstudianteServicio {
    @Autowired
    private EstudianteRepositorio estudianteRepositorio;

    private static final String FILE_PATH = "estudiantesynotas.json";
    private ObjectMapper objectMapper = new ObjectMapper();

    // Crear o actualizar un estudiante
    public EstudianteModelo saveOrUpdateEstudiante(EstudianteModelo estudiante) {
        EstudianteModelo savedEstudiante = estudianteRepositorio.save(estudiante);
        saveToFile();
        return savedEstudiante;
    }

    // Obtener todos los estudiantes
    public List<EstudianteModelo> getAllEstudiantes() {
        return estudianteRepositorio.findAll();
    }

    // Obtener un estudiante por ID
    public Optional<EstudianteModelo> getEstudianteById(Long id) {
        return estudianteRepositorio.findById(id);
    }

    // Eliminar un estudiante por ID
    public void deleteEstudianteById(Long id) {
        estudianteRepositorio.deleteById(id);
        saveToFile();
    }

    private void saveToFile() {
        List<EstudianteModelo> estudiantes = estudianteRepositorio.findAll();
        try {
            objectMapper.writeValue(new File(FILE_PATH), estudiantes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}