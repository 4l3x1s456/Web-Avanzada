package com.example.Base_Calificaciones_20.repositorio;

import com.example.Base_Calificaciones_20.modelo.NotaModelo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface NotaRepositorio extends JpaRepository<NotaModelo, Long> {
    List<NotaModelo> findByEstudianteId(Long estudianteId);
}