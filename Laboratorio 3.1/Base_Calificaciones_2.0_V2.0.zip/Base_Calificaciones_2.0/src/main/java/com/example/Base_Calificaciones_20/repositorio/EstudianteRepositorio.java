package com.example.Base_Calificaciones_20.repositorio;

import com.example.Base_Calificaciones_20.modelo.EstudianteModelo;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EstudianteRepositorio extends JpaRepository<EstudianteModelo, Long> {
}
