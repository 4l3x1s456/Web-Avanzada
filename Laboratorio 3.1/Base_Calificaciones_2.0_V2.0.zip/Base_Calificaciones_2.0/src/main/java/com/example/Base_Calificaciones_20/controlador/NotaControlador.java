package com.example.Base_Calificaciones_20.controlador;

import com.example.Base_Calificaciones_20.modelo.NotaModelo;
import com.example.Base_Calificaciones_20.servicio.NotaServicio;
import com.example.Base_Calificaciones_20.servicio.EstudianteServicio;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/notas")
public class NotaControlador {

    @Autowired
    private NotaServicio notaServicio;

    @Autowired
    private EstudianteServicio estudianteServicio;

    @GetMapping("/estudiante/{estudianteId}")
    public String listarNotas(@PathVariable Long estudianteId, Model model) {
        List<NotaModelo> notas = notaServicio.getNotasByEstudianteId(estudianteId);
        model.addAttribute("notas", notas);
        model.addAttribute("estudianteId", estudianteId);
        return "notas";
    }

    @GetMapping("/estudiante/{estudianteId}/nueva")
    public String mostrarFormularioDeRegistro(@PathVariable Long estudianteId, Model model) {
        NotaModelo nota = new NotaModelo();
        nota.setEstudiante(estudianteServicio.getEstudianteById(estudianteId).orElse(null));
        model.addAttribute("nota", nota);
        return "crear_nota";
    }

    @PostMapping("/estudiante/{estudianteId}")
    public String guardarNota(@PathVariable Long estudianteId, @ModelAttribute("nota") NotaModelo nota) {
        nota.setEstudiante(estudianteServicio.getEstudianteById(estudianteId).orElse(null));
        // Convertir la nota a double
        double notaValor = Double.parseDouble(String.valueOf(nota.getNota()));
        nota.setNota(notaValor);
        notaServicio.saveOrUpdateNota(nota);
        return "redirect:/notas/estudiante/" + estudianteId;
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioDeEdicion(@PathVariable Long id, Model model) {
        NotaModelo nota = notaServicio.getNotaById(id).orElse(null);
        model.addAttribute("nota", nota);
        return "editar_nota";
    }

    @PostMapping("/editar/{id}")
    public String actualizarNota(@PathVariable Long id, @ModelAttribute("nota") NotaModelo nota) {
        nota.setId(id);
        // Convertir la nota a double
        double notaValor = Double.parseDouble(String.valueOf(nota.getNota()));
        nota.setNota(notaValor);
        notaServicio.saveOrUpdateNota(nota);
        return "redirect:/notas/estudiante/" + nota.getEstudiante().getId();
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarNota(@PathVariable Long id) {
        NotaModelo nota = notaServicio.getNotaById(id).orElse(null);
        if (nota != null) {
            Long estudianteId = nota.getEstudiante().getId();
            notaServicio.deleteNotaById(id);
            return "redirect:/notas/estudiante/" + estudianteId;
        }
        return "redirect:/estudiantes";
    }
}