package com.example.Base_Calificaciones_20.servicio;

import com.example.Base_Calificaciones_20.modelo.EstudianteModelo;
import com.example.Base_Calificaciones_20.modelo.NotaModelo;
import com.example.Base_Calificaciones_20.repositorio.NotaRepositorio;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;

@Service
public class NotaServicio {

    @Autowired
    private NotaRepositorio notaRepositorio;

    @Autowired
    private EstudianteServicio estudianteServicio;

    private static final String FILE_PATH = "estudiantesynotas.json";
    private ObjectMapper objectMapper = new ObjectMapper();

    // Crear o actualizar una nota
    public NotaModelo saveOrUpdateNota(NotaModelo nota) {
        NotaModelo savedNota = notaRepositorio.save(nota);
        saveToFile();
        return savedNota;
    }

    // Obtener todas las notas
    public List<NotaModelo> getAllNotas() {
        return notaRepositorio.findAll();
    }

    // Obtener una nota por ID
    public Optional<NotaModelo> getNotaById(Long id) {
        return notaRepositorio.findById(id);
    }

    // Eliminar una nota por ID
    public void deleteNotaById(Long id) {
        notaRepositorio.deleteById(id);
        saveToFile();
    }

    // Obtener todas las notas de un estudiante
    public List<NotaModelo> getNotasByEstudianteId(Long estudianteId) {
        return notaRepositorio.findByEstudianteId(estudianteId);
    }

    private void saveToFile() {
        List<EstudianteModelo> estudiantes = estudianteServicio.getAllEstudiantes();
        try {
            objectMapper.writeValue(new File(FILE_PATH), estudiantes);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}