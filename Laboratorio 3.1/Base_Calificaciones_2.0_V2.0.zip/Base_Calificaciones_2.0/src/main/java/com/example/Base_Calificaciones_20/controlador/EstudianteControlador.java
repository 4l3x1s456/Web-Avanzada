package com.example.Base_Calificaciones_20.controlador;

import com.example.Base_Calificaciones_20.modelo.EstudianteModelo;
import com.example.Base_Calificaciones_20.servicio.EstudianteServicio;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/estudiantes")
public class EstudianteControlador {

    @Autowired
    private EstudianteServicio estudianteServicio;

    @GetMapping
    public String listarEstudiantes(@RequestParam(required = false) Double notaMin, @RequestParam(required = false) Double notaMax, Model model) {
        List<EstudianteModelo> estudiantes = estudianteServicio.getAllEstudiantes();
        if (notaMin != null) {
            estudiantes = estudiantes.stream().filter(e -> e.getNotas().stream().anyMatch(n -> n.getNota() >= notaMin)).collect(Collectors.toList());
        }
        if (notaMax != null) {
            estudiantes = estudiantes.stream().filter(e -> e.getNotas().stream().anyMatch(n -> n.getNota() <= notaMax)).collect(Collectors.toList());
        }
        estudiantes.sort(Comparator.comparingDouble(e -> e.getNotas().stream().mapToDouble(n -> n.getNota()).average().orElse(0.0)));
        model.addAttribute("estudiantes", estudiantes);
        return "estudiantes";
    }

    @GetMapping("/nuevo")
    public String mostrarFormularioDeRegistro(Model model) {
        model.addAttribute("estudiante", new EstudianteModelo());
        return "crear_estudiante";
    }

    @PostMapping
    public String guardarEstudiante(@ModelAttribute("estudiante") EstudianteModelo estudiante) {
        estudianteServicio.saveOrUpdateEstudiante(estudiante);
        return "redirect:/estudiantes";
    }

    @GetMapping("/editar/{id}")
    public String mostrarFormularioDeEdicion(@PathVariable Long id, Model model) {
        EstudianteModelo estudiante = estudianteServicio.getEstudianteById(id).orElse(null);
        model.addAttribute("estudiante", estudiante);
        return "editar_estudiante";
    }

    @PostMapping("/{id}")
    public String actualizarEstudiante(@PathVariable Long id, @ModelAttribute("estudiante") EstudianteModelo estudiante) {
        estudiante.setId(id);
        estudianteServicio.saveOrUpdateEstudiante(estudiante);
        return "redirect:/estudiantes";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminarEstudiante(@PathVariable Long id) {
        estudianteServicio.deleteEstudianteById(id);
        return "redirect:/estudiantes";
    }

    @GetMapping("/reporte/csv")
    public void generarReporteCSV(HttpServletResponse response) throws IOException {
        response.setContentType("text/csv");
        response.setHeader("Content-Disposition", "attachment; filename=estudiantes.csv");
        List<EstudianteModelo> estudiantes = estudianteServicio.getAllEstudiantes();
        try (PrintWriter writer = response.getWriter()) {
            writer.println("ID,Nombre,Apellido,Email,Fecha de Nacimiento");
            for (EstudianteModelo estudiante : estudiantes) {
                writer.printf("%d,%s,%s,%s,%s%n",
                        estudiante.getId(),
                        estudiante.getNombre(),
                        estudiante.getApellido(),
                        estudiante.getEmail(),
                        estudiante.getFechaNacimiento().toString());
            }
        }
    }
}